package controller;

import javafx.event.*;
import javafx.scene.input.KeyEvent;
import view.Center;

public class MovementController implements EventHandler <KeyEvent>{

	private Center pane;
	
	public MovementController(Center pane){
		this.pane = pane;
	}
	
	public void handle(KeyEvent e) {
		
		System.out.println("2");
		
		switch(e.getCode()){
		
			case W: 
				pane.getPlayer().moveUp();
				System.out.println("W");
				break;
			case S: 
				pane.getPlayer().moveDown();
				System.out.println("S");
				break;
			case A: 
				pane.getPlayer().moveLeft();
				System.out.println("A");
				break;
			case D: 
				pane.getPlayer().moveRight();
				System.out.println("D");
				break;
			default:
				break;	
		}
		pane.refreshPlayer();
		
	}

	
	

}
