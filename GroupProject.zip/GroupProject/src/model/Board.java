package model;

import tiles.Tile;

public class Board {

	private Tile[][] board;
	
	public Board(int x, int y) {
		board = new Tile [x][y];		
	}
	
	public void addTile(Tile tile, int x, int y) {
		board[x][y] = tile;
	}
	
	public void removeTile(int x, int y) {
		board[x][y] = null;
	}
}
