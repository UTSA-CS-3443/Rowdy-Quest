package tiles;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Tile extends Space{

	private boolean isWalkable;
	
		public Tile(Image image, int y, int x, boolean isWalkable) {//no wrapper
			super(image, x, y);
			this.setIsWalkable(isWalkable);
		}
	
		public Tile(ImageView image, int x, int y, boolean isWalkable) { //wrapper
			super(image, x, y);
			this.setIsWalkable(isWalkable);
		}

		public boolean getIsWalkable() {
			return isWalkable;
		}

		public void setIsWalkable(boolean isWalkable) {
			this.isWalkable = isWalkable;
		}

		
		
}
