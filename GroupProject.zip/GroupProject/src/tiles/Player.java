package tiles;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Player extends Space{

	public Player(Image image, int x, int y) {//no wrapper
		super(image, x, y);
	}
	
	public Player(ImageView image, int x, int y) {//wrapper
		super(image, x, y);
	}
	public void moveUp(){
		setY(getY() - 1);
	}
	public void moveDown(){
		setY(getY() + 1);
	}
	public void moveLeft(){
		setX(getX() - 1);
	}
	public void moveRight(){
		setX(getX() + 1);
	}
}
