package tiles;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Space {
	
	private ImageView image;
	private int x, y;
	public final int GRID_SQUARE = 30;
	
		public Space( ImageView image, int x, int y){ //wrapper
			this.x = x;
			this.y = y;
			this.image = image;
			setImageSize();
		}
		
		public Space(Image image, int x, int y){ //no wrapper
			this.x = x;
			this.y = y;
			this.image = new ImageView(image);
			setImageSize();
		}
	
		public int getX() {
			return x;
		}

		public void setX(int x) {
			this.x = x;
		}

		public int getY() {
			return y;
		}

		public void setY(int y) {
			this.y = y;
		}

		public ImageView getImage() {
			return image;
		}

		public void setImage(ImageView playerImage) {
			this.image = playerImage;
		}

		private void setImageSize(){
			image.setFitHeight(GRID_SQUARE);
			image.setFitWidth(GRID_SQUARE);
		}
	
		public String toString(){
			return "Player at " + x + " " + y;
		}
	
}
