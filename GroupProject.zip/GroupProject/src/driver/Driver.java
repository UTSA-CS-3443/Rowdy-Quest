package driver;


import view.Root;
import controller.MovementController;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Driver extends Application{

	public static void main(String[] args) {
		launch(args);
	}

	public void start(Stage stage) throws Exception {
		
		BorderPane root = new Root();
		Scene scene = new Scene(root, 800, 600, Color.BLACK);
		stage.setScene(scene);
		stage.setTitle("RowdyQuest");
		stage.show();
	}

}
