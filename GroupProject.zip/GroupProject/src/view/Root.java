package view;

import controller.MovementController;
import javafx.scene.layout.BorderPane;

public class Root extends BorderPane{

	private Center center;
	private TopBar top;
	
	public Root(){
		
		//top
		top = new TopBar();
		setTop(top);
		
		//center
		center = new Center();
		setCenter(center);
		
		//button input
		MovementController con = new MovementController(center);
		setOnKeyPressed(con);
		
	}
	
	
}
