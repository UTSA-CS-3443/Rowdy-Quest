package view;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;

public class TopBar extends HBox {
	
	public TopBar(){

		setPadding(new Insets(15,15,15,15));
		setSpacing(10);
		setStyle("-fx-background-color: #000000;");
		
		Button btn = new Button("Test");
		Button btnq = new Button("Test");
		
		ComboBox<String> combobox = new ComboBox<String>();
		combobox.getItems().addAll("1", "2", "3", "4", "5");
		
		
		TextField textBox = new TextField("r");
		if(textBox.getText().equals("r"))
			combobox.getItems().add("r");
		
		getChildren().addAll(btn, btnq, combobox, textBox);
		
		
		
	}
	
	
	
	
	
	
	
}
