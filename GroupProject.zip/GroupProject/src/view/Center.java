package view;

import javafx.scene.image.Image;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import tiles.Player;
import tiles.Tile;

public class Center extends GridPane{

	private Player player;
	private Tile circleTile;
	private Tile pentTile;
	
	private final int WIDTH = 50;
	private final int HEIGTH = 50;
	
		public Center(){

			//player
			player = new Player(new Image("File:rect.png"),3,3);
			
			//board
			configBoard();
			
			//puts stuff on the board
			for(int i = 0; i < WIDTH; i++)
				for(int j = 0; j < HEIGTH; j++)
				{	
					circleTile = new Tile(new Image("File:circle.png"),i,j,true);
					add(circleTile.getImage(),i,j);
				}
			add(player.getImage(),player.getX(),player.getY()); //adds player to board
		}
		
		
		public Player getPlayer(){
			return player;
		}
		
		public void refreshPlayer(){ //Refreshes player's location
			add(player.getImage(),player.getX(),player.getY());
			
		}
		
		private void configBoard(){
		
			for(int i = 0; i < WIDTH; i++){
				ColumnConstraints colConst = new ColumnConstraints();
				colConst.setPercentWidth(100.0/WIDTH);
				getColumnConstraints().add(colConst);
			}
			
			for(int i = 0; i < HEIGTH; i++){
				RowConstraints rowConst = new RowConstraints();
				rowConst.setPercentHeight(100.0/HEIGTH);
				getRowConstraints().add(rowConst);
			}
			
		}
		
	}
